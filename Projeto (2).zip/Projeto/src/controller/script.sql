CREATE TABLE tb_usuario (
    id SERIAL NOT NULL,
    usuario character varying(255),
    senha character varying(32),
	constraint pk_usuario_id primary key (id)
);

INSERT INTO tb_usuario (usuario,senha)
	values ('joao', md5('123456'))
	
SELECT * FROM tb_usuario;

